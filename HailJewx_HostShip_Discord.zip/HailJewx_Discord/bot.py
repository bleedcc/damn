"""HailJewx Discord bot for Python bot hosting (HostShip-style startup)."""
from __future__ import annotations

import io
import os
import logging
from pathlib import Path

import discord
from discord import app_commands
from discord.ext import commands

from obfuscator.compiler import compile_source, CompileError
from obfuscator.transformations import transform_bytecode
from obfuscator.bytecode import encode_program, BytecodeError

logging.basicConfig(
    level=os.getenv("HAILJEWX_LOG_LEVEL", "INFO").upper(),
    format="%(asctime)s %(levelname)s %(name)s: %(message)s",
)
log = logging.getLogger("hailjewx")

TOKEN = os.getenv("DISCORD_TOKEN", "").strip()
MAX_SOURCE_BYTES = 500_000
ALLOWED_EXTENSIONS = {".lua", ".luau", ".txt"}

intents = discord.Intents.default()
bot = commands.Bot(command_prefix="!", intents=intents)


@bot.event
async def on_ready():
    try:
        synced = await bot.tree.sync()
        log.info("Synced %s slash command(s).", len(synced))
    except Exception:
        log.exception("Failed to sync slash commands")
    log.info("Logged in as %s (ID: %s)", bot.user, bot.user.id if bot.user else "unknown")


@bot.tree.command(name="hail", description="Obfuscate a supported Lua/Luau file with HailJewx.")
@app_commands.describe(file="Upload a .lua, .luau, or .txt source file")
async def hail(interaction: discord.Interaction, file: discord.Attachment):
    """Slash command requested by the user: /hail file:<attachment>."""
    await interaction.response.defer(thinking=True, ephemeral=True)

    suffix = Path(file.filename).suffix.lower()
    if suffix not in ALLOWED_EXTENSIONS:
        await interaction.followup.send(
            "Please attach a `.lua`, `.luau`, or `.txt` source file.", ephemeral=True
        )
        return
    if file.size > MAX_SOURCE_BYTES:
        await interaction.followup.send(
            f"That file is too large. The limit is {MAX_SOURCE_BYTES // 1000} KB.", ephemeral=True
        )
        return

    try:
        raw = await file.read()
        if len(raw) > MAX_SOURCE_BYTES:
            raise ValueError("The uploaded file exceeds the size limit.")
        source = raw.decode("utf-8-sig")
        program = compile_source(source)
        transformed = transform_bytecode(program, shuffle_constants=True)
        payload = encode_program(transformed)
        runtime_path = Path(__file__).parent / "obfuscator" / "luau_runtime.luau"
        runtime = runtime_path.read_text(encoding="utf-8")
        output = runtime.replace(
            "--[[ HAILJEWX_PROGRAM_PLACEHOLDER ]]",
            "local PROGRAM = " + payload,
        )
        output = "--this has been obfuscated with hailjewx\n" + output
        out_name = Path(file.filename).stem + ".hailjewx.luau"
        data = io.BytesIO(output.encode("utf-8"))
        await interaction.followup.send(
            content=f"✅ **HailJewx finished:** `{file.filename}` → `{out_name}`",
            file=discord.File(data, filename=out_name),
            ephemeral=True,
        )
    except (UnicodeDecodeError, CompileError, BytecodeError, OSError, ValueError) as exc:
        message = str(exc)
        if len(message) > 1500:
            message = message[:1500] + "…"
        await interaction.followup.send(
            f"❌ Could not obfuscate that file:\n```text\n{message}\n```\n"
            "This version supports only the subset documented in README.md.",
            ephemeral=True,
        )
    except Exception:
        log.exception("Unexpected failure while processing %s", file.filename)
        await interaction.followup.send(
            "❌ An unexpected error occurred while processing the file. Check the host logs.",
            ephemeral=True,
        )


@bot.tree.command(name="hailhelp", description="Show HailJewx bot usage and limitations.")
async def hailhelp(interaction: discord.Interaction):
    await interaction.response.send_message(
        "**HailJewx usage**\n"
        "1. Run `/hail file:` and attach a `.lua` or `.luau` file.\n"
        "2. The bot returns a `.hailjewx.luau` file.\n\n"
        "**Current supported syntax:** literals, variables, arithmetic, comparisons, "
        "`if/else`, `while`, and `return`.\n"
        "Functions, function calls, tables, indexing, and most Roblox API scripts are not "
        "supported yet. Obfuscation is not cryptographic protection.",
        ephemeral=True,
    )


def main() -> None:
    if not TOKEN:
        raise SystemExit(
            "Missing DISCORD_TOKEN environment variable. Set it in your host's environment variables."
        )
    bot.run(TOKEN, log_handler=None)


if __name__ == "__main__":
    main()
