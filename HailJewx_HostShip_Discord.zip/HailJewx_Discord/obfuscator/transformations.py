"""Safe bytecode transformations: constant-pool shuffling and instruction remapping."""
from __future__ import annotations
import random
from typing import Any
from .bytecode import verify_program

def transform_bytecode(program: dict[str, Any], seed: int | None = None,
                       shuffle_constants: bool = True) -> dict[str, Any]:
    """Return a transformed copy. No anti-debugging, network, or environment checks."""
    verify_program(program)
    rng = random.Random(seed)
    constants = list(program["constants"])
    code = [list(ins) for ins in program["code"]]
    if shuffle_constants and len(constants) > 1:
        order = list(range(len(constants)))
        rng.shuffle(order)
        old_to_new = {old: new for new, old in enumerate(order)}
        constants = [constants[old] for old in order]
        for ins in code:
            if ins[0] == "CONST":
                ins[1] = old_to_new[ins[1]]
    # Shuffle the spelling of operation names consistently. This is a simple
    # packaging transformation, not cryptographic protection.
    op_names = sorted({ins[0] for ins in code})
    shuffled = op_names[:]
    rng.shuffle(shuffled)
    rename = dict(zip(op_names, shuffled))
    transformed = [[rename[ins[0]], *ins[1:]] for ins in code]
    # The Python VM and Luau runtime need canonical op names, so this mapping
    # is recorded in the program and decoded by the runtime.
    result = {"version": program["version"], "constants": constants,
              "code": transformed, "opmap": {v: k for k, v in rename.items()}}
    return result
