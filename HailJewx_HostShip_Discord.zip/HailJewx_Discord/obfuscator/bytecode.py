"""Bytecode format, verifier, and reference stack VM."""
from __future__ import annotations
import json
import math
from typing import Any

FORMAT_VERSION = 1
class BytecodeError(ValueError): pass

def encode_program(program: dict[str, Any]) -> str:
    verify_program(program)
    return json.dumps(program, ensure_ascii=False, separators=(",", ":"))

def decode_program(payload: str) -> dict[str, Any]:
    try: obj = json.loads(payload)
    except json.JSONDecodeError as exc: raise BytecodeError(f"invalid bytecode JSON: {exc}") from exc
    verify_program(obj)
    return obj

def verify_program(program: dict[str, Any]) -> None:
    if not isinstance(program, dict) or program.get("version") != FORMAT_VERSION:
        raise BytecodeError("unsupported or missing bytecode version")
    code, consts = program.get("code"), program.get("constants")
    if not isinstance(code, list) or not isinstance(consts, list):
        raise BytecodeError("code and constants must be arrays")
    allowed = {"CONST", "LOAD", "STORE", "POP", "UNARY", "BINARY", "JUMP", "JUMP_IF_FALSE", "RETURN"}
    opmap = program.get("opmap", {})
    if not isinstance(opmap, dict):
        raise BytecodeError("opmap must be an object")
    for pc, ins in enumerate(code):
        if not isinstance(ins, list) or not ins or not isinstance(ins[0], str):
            raise BytecodeError(f"invalid instruction at {pc}")
        op = opmap.get(ins[0], ins[0])
        if op not in allowed:
            raise BytecodeError(f"invalid instruction at {pc}")
        if op == "CONST" and (len(ins) != 2 or not isinstance(ins[1], int) or not 0 <= ins[1] < len(consts)):
            raise BytecodeError(f"invalid constant reference at {pc}")
        if op in ("LOAD", "STORE") and (len(ins) != 2 or not isinstance(ins[1], str)):
            raise BytecodeError(f"invalid variable instruction at {pc}")
        if op in ("JUMP", "JUMP_IF_FALSE") and (len(ins) != 2 or not isinstance(ins[1], int) or not 0 <= ins[1] <= len(code)):
            raise BytecodeError(f"invalid jump at {pc}")
        if op == "BINARY" and (len(ins) != 2 or ins[1] not in ("+", "-", "*", "/", "%", "^", "==", "~=", "<", ">", "<=", ">=", "AND", "OR")):
            raise BytecodeError(f"invalid binary operation at {pc}")
        if op == "UNARY" and (len(ins) != 2 or ins[1] not in ("-", "not")):
            raise BytecodeError(f"invalid unary operation at {pc}")

def _truthy(value: Any) -> bool:
    return value is not None and value is not False

def _binary(op: str, a: Any, b: Any) -> Any:
    if op == "+": return a + b
    if op == "-": return a - b
    if op == "*": return a * b
    if op == "/": return a / b
    if op == "%": return a % b
    if op == "^": return a ** b
    if op == "==": return a == b
    if op == "~=": return a != b
    if op == "<": return a < b
    if op == ">": return a > b
    if op == "<=": return a <= b
    if op == ">=": return a >= b
    if op == "AND": return b if _truthy(a) else a
    if op == "OR": return a if _truthy(a) else b
    raise BytecodeError(f"unknown binary operator {op!r}")

def run_program(program: dict[str, Any], env: dict[str, Any] | None = None, max_steps: int = 1_000_000) -> Any:
    verify_program(program)
    code, consts = program["code"], program["constants"]
    env = {} if env is None else env
    locals_: dict[str, Any] = {}
    stack: list[Any] = []
    pc = steps = 0
    while pc < len(code):
        steps += 1
        if steps > max_steps: raise BytecodeError("instruction limit exceeded")
        ins = code[pc]; pc += 1; op = program.get("opmap", {}).get(ins[0], ins[0])
        if op == "CONST": stack.append(consts[ins[1]])
        elif op == "LOAD": stack.append(locals_[ins[1]] if ins[1] in locals_ else env.get(ins[1]))
        elif op == "STORE": locals_[ins[1]] = stack.pop()
        elif op == "POP": stack.pop()
        elif op == "UNARY":
            v = stack.pop()
            stack.append(-v if ins[1] == "-" else not _truthy(v))
        elif op == "BINARY":
            b, a = stack.pop(), stack.pop()
            stack.append(_binary(ins[1], a, b))
        elif op == "JUMP": pc = ins[1]
        elif op == "JUMP_IF_FALSE":
            if not _truthy(stack.pop()): pc = ins[1]
        elif op == "RETURN": return stack.pop() if ins[1] else None
    return None
