"""Recursive-descent statement parser and Pratt expression parser."""
from __future__ import annotations
from dataclasses import dataclass
from .lexer import Token, tokenize, LexError

class ParseError(ValueError):
    pass

@dataclass
class Node:
    kind: str
    value: object = None
    children: list["Node"] | None = None
    line: int = 0

PRECEDENCE = {"OR": 1, "AND": 2, "==": 3, "~=": 3, "<": 3, ">": 3, "<=": 3, ">=": 3,
              "+": 4, "-": 4, "*": 5, "/": 5, "%": 5, "^": 6}

class Parser:
    def __init__(self, tokens: list[Token]):
        self.tokens = tokens
        self.i = 0

    def cur(self) -> Token: return self.tokens[self.i]
    def take(self) -> Token:
        t = self.cur(); self.i += 1; return t
    def accept(self, kind: str, value=None) -> Token | None:
        t = self.cur()
        if t.kind == kind and (value is None or t.value == value):
            self.i += 1
            return t
        return None
    def expect(self, kind: str, value=None) -> Token:
        t = self.accept(kind, value)
        if t is None:
            cur = self.cur()
            raise ParseError(f"expected {value or kind} at {cur.line}:{cur.column}, got {cur.value!r}")
        return t

    def parse(self) -> Node:
        body = self.block({"EOF"})
        self.expect("EOF")
        return Node("block", children=body)

    def block(self, stops: set[str]) -> list[Node]:
        out = []
        while self.cur().kind not in stops and self.cur().kind != "EOF":
            if self.accept(";"): continue
            out.append(self.statement())
            self.accept(";")
        return out

    def statement(self) -> Node:
        t = self.cur()
        if self.accept("LOCAL"):
            name = self.expect("IDENT")
            self.expect("OP", "=")
            expr = self.expression()
            return Node("local", name.value, [expr], t.line)
        if self.accept("RETURN"):
            if self.cur().kind in ("EOF", "END", "ELSE", ";"):
                return Node("return", children=[], line=t.line)
            return Node("return", children=[self.expression()], line=t.line)
        if self.accept("IF"):
            cond = self.expression()
            self.expect("THEN")
            yes = self.block({"ELSE", "END"})
            no = []
            if self.accept("ELSE"):
                no = self.block({"END"})
            self.expect("END")
            return Node("if", children=[cond, Node("block", children=yes), Node("block", children=no)], line=t.line)
        if self.accept("WHILE"):
            cond = self.expression()
            self.expect("DO")
            body = self.block({"END"})
            self.expect("END")
            return Node("while", children=[cond, Node("block", children=body)], line=t.line)
        if t.kind == "IDENT":
            name = self.take()
            self.expect("OP", "=")
            return Node("assign", name.value, [self.expression()], t.line)
        raise ParseError(f"unsupported statement {t.value!r} at {t.line}:{t.column}")

    def expression(self, min_prec: int = 0) -> Node:
        t = self.take()
        if t.kind in ("NUMBER", "STRING"):
            left = Node("literal", t.value, line=t.line)
        elif t.kind in ("TRUE", "FALSE", "NIL"):
            left = Node("literal", {"TRUE": True, "FALSE": False, "NIL": None}[t.kind], line=t.line)
        elif t.kind == "IDENT":
            left = Node("name", t.value, line=t.line)
        elif t.kind == "OP" and t.value in ("-",):
            left = Node("unary", t.value, [self.expression(7)], t.line)
        elif t.kind == "NOT":
            left = Node("unary", "not", [self.expression(7)], t.line)
        elif t.kind == "(":
            left = self.expression()
            self.expect(")")
        else:
            raise ParseError(f"expected expression at {t.line}:{t.column}, got {t.value!r}")

        while True:
            op_token = self.cur()
            op = op_token.value if op_token.kind == "OP" else op_token.kind
            prec = PRECEDENCE.get(op, -1)
            if prec < min_prec:
                break
            self.take()
            # Exponentiation is right associative; all other operators are left associative.
            right = self.expression(prec if op == "^" else prec + 1)
            left = Node("binary", op, [left, right], op_token.line)
        return left

def parse(source: str) -> Node:
    return Parser(tokenize(source)).parse()
