"""Lexer for the intentionally small, documented HailJewx Luau subset."""
from __future__ import annotations
from dataclasses import dataclass

class LexError(ValueError):
    pass

@dataclass(frozen=True)
class Token:
    kind: str
    value: object
    line: int
    column: int

KEYWORDS = {"local", "return", "if", "then", "else", "end", "while", "do",
            "true", "false", "nil", "and", "or", "not"}

class Lexer:
    def __init__(self, source: str):
        self.source = source
        self.i = 0
        self.line = 1
        self.column = 1
        self.tokens: list[Token] = []

    def _peek(self, n: int = 0) -> str:
        p = self.i + n
        return self.source[p] if p < len(self.source) else ""

    def _advance(self) -> str:
        ch = self._peek()
        if ch:
            self.i += 1
            if ch == "\n":
                self.line += 1
                self.column = 1
            else:
                self.column += 1
        return ch

    def _emit(self, kind: str, value: object, line: int, col: int) -> None:
        self.tokens.append(Token(kind, value, line, col))

    def tokenize(self) -> list[Token]:
        while self._peek():
            ch = self._peek()
            if ch.isspace():
                self._advance()
                continue
            if ch == "-" and self._peek(1) == "-":
                self._advance(); self._advance()
                while self._peek() and self._peek() != "\n":
                    self._advance()
                continue
            line, col = self.line, self.column
            if ch.isdigit():
                start = self.i
                while self._peek().isdigit():
                    self._advance()
                if self._peek() == "." and self._peek(1).isdigit():
                    self._advance()
                    while self._peek().isdigit():
                        self._advance()
                raw = self.source[start:self.i]
                self._emit("NUMBER", float(raw) if "." in raw else int(raw), line, col)
                continue
            if ch in "'\"":
                quote = self._advance()
                chars = []
                while self._peek() and self._peek() != quote:
                    c = self._advance()
                    if c == "\\":
                        esc = self._advance()
                        mapping = {"n": "\n", "r": "\r", "t": "\t", "\\": "\\", "'": "'", '"': '"'}
                        if not esc:
                            raise LexError(f"unterminated escape at {line}:{col}")
                        chars.append(mapping.get(esc, esc))
                    else:
                        chars.append(c)
                if self._peek() != quote:
                    raise LexError(f"unterminated string at {line}:{col}")
                self._advance()
                self._emit("STRING", "".join(chars), line, col)
                continue
            if ch.isalpha() or ch == "_":
                start = self.i
                while self._peek().isalnum() or self._peek() == "_":
                    self._advance()
                word = self.source[start:self.i]
                self._emit(word.upper() if word in KEYWORDS else "IDENT", word, line, col)
                continue
            two = ch + self._peek(1)
            if two in ("==", "~=", "<=", ">="):
                self._advance(); self._advance()
                self._emit("OP", two, line, col)
                continue
            if ch in "+-*/%^<>=":
                self._advance()
                self._emit("OP", ch, line, col)
                continue
            if ch in "(),;":
                self._advance()
                self._emit(ch, ch, line, col)
                continue
            raise LexError(f"unexpected character {ch!r} at {line}:{col}")
        self.tokens.append(Token("EOF", None, self.line, self.column))
        return self.tokens

def tokenize(source: str) -> list[Token]:
    return Lexer(source).tokenize()
