"""HailJewx educational Luau-subset compiler and virtual machine."""
__version__ = "1.0.0"
