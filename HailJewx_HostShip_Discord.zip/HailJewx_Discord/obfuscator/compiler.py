"""Compile the supported source subset into stack-machine bytecode."""
from __future__ import annotations
from typing import Any
from .parser import parse, Node, ParseError
from .lexer import LexError
from .bytecode import FORMAT_VERSION, verify_program, BytecodeError

class CompileError(ValueError): pass

class Compiler:
    def __init__(self):
        self.code: list[list[Any]] = []
        self.constants: list[Any] = []
        self.constant_index: dict[tuple, int] = {}

    def emit(self, *ins) -> int:
        self.code.append(list(ins)); return len(self.code) - 1

    def patch(self, pc: int, target: int) -> None:
        self.code[pc][1] = target

    def const(self, value: Any) -> int:
        key = (type(value).__name__, value)
        if key not in self.constant_index:
            self.constant_index[key] = len(self.constants)
            self.constants.append(value)
        return self.constant_index[key]

    def expr(self, node: Node) -> None:
        if node.kind == "literal": self.emit("CONST", self.const(node.value))
        elif node.kind == "name": self.emit("LOAD", node.value)
        elif node.kind == "unary":
            self.expr(node.children[0]); self.emit("UNARY", node.value)
        elif node.kind == "binary":
            self.expr(node.children[0]); self.expr(node.children[1]); self.emit("BINARY", node.value)
        else: raise CompileError(f"unsupported expression node {node.kind}")

    def block(self, node: Node) -> None:
        for stmt in node.children or []: self.stmt(stmt)

    def stmt(self, node: Node) -> None:
        if node.kind in ("local", "assign"):
            self.expr(node.children[0]); self.emit("STORE", node.value)
        elif node.kind == "return":
            if node.children: self.expr(node.children[0])
            self.emit("RETURN", 1 if node.children else 0)
        elif node.kind == "if":
            self.expr(node.children[0])
            false_jump = self.emit("JUMP_IF_FALSE", 0)
            self.block(node.children[1])
            if node.children[2].children:
                end_jump = self.emit("JUMP", 0)
                self.patch(false_jump, len(self.code))
                self.block(node.children[2])
                self.patch(end_jump, len(self.code))
            else:
                self.patch(false_jump, len(self.code))
        elif node.kind == "while":
            start = len(self.code)
            self.expr(node.children[0])
            end_jump = self.emit("JUMP_IF_FALSE", 0)
            self.block(node.children[1])
            self.emit("JUMP", start)
            self.patch(end_jump, len(self.code))
        elif node.kind == "block": self.block(node)
        else: raise CompileError(f"unsupported statement {node.kind}")

def compile_source(source: str) -> dict[str, Any]:
    try:
        tree = parse(source)
        c = Compiler()
        c.block(tree)
        if not c.code or c.code[-1][0] != "RETURN":
            c.emit("RETURN", 0)
        program = {"version": FORMAT_VERSION, "constants": c.constants, "code": c.code}
        verify_program(program)
        return program
    except (LexError, ParseError, BytecodeError) as exc:
        raise CompileError(str(exc)) from exc
