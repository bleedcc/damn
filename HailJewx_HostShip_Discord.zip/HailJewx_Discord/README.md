# HailJewx Discord Bot

A Python Discord bot that exposes the HailJewx educational Luau-subset compiler as the slash command **`/hail file:`**. Upload a supported `.lua`, `.luau`, or `.txt` file and the bot replies with a generated `.hailjewx.luau` file.

## HostShip Python bot hosting (startup file: `bot.py`)

1. Upload/extract this project so `bot.py`, `requirements.txt`, and the `obfuscator/` directory are in the same project root.
2. Set the startup/entry file to `bot.py`.
3. Install dependencies from `requirements.txt` (the host may do this automatically).
4. In the host's environment variables, add `DISCORD_TOKEN` with your bot token. Optionally set `HAILJEWX_LOG_LEVEL=INFO`.
5. In the Discord Developer Portal, enable the application/bot and invite it to your server with the `applications.commands` scope and permission to send messages/attach files.
6. Start/restart the host. On first startup, slash commands are synced globally; Discord can take a little time to display new commands.

**Never paste your bot token into public chat or commit it to GitHub.** If exposed, reset it in the Discord Developer Portal.

## Discord usage

In a server where the bot is installed, run:

`/hail file:` and attach a `.lua`, `.luau`, or `.txt` file.

Use `/hailhelp` for the bot's short help message. The bot has a 500 KB source-file limit and responds privately to the invoking user.

## Supported source subset

The parser/compiler supports:
- number, string, boolean, and nil literals
- local declarations (`local x = expression`) and assignments (`x = expression`)
- arithmetic, comparisons, `and`, `or`, unary `-`, and `not`
- `if ... then ... else ... end`
- `while ... do ... end`
- `return`

It does **not** currently support functions/calls, tables, indexing, closures, multiple assignment, `for`, `repeat`, type annotations, or general Roblox APIs. For example, `print("hello")` is not supported yet. Unsupported syntax returns a compiler error rather than pretending to obfuscate it.

## What the transformations do—and don't do

The generated output includes:

`--this has been obfuscated with hailjewx`

HailJewx packages compiled bytecode into a custom stack VM runtime and applies constant-pool shuffling and opcode-name remapping. This is a learning/prototype project, not a commercial-grade protector; transformations are reversible and do not prevent reverse engineering. The runtime is not a sandbox for untrusted code.

## Local testing

Python 3.10+ is recommended.

```bash
python -m pip install -r requirements.txt
python -m unittest discover -s tests -v
```

The tests use the standard library and do not require a Discord token. To start the bot locally, set `DISCORD_TOKEN` in your environment and run `python bot.py`.
