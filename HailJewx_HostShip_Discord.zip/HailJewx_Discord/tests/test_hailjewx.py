import unittest
from obfuscator.compiler import compile_source, CompileError
from obfuscator.bytecode import run_program, encode_program, decode_program, BytecodeError
from obfuscator.transformations import transform_bytecode

class HailJewxTests(unittest.TestCase):
    def test_arithmetic_and_return(self):
        p = compile_source("local x = 6 * 7 return x")
        self.assertEqual(run_program(p), 42)

    def test_if_else(self):
        p = compile_source("local x = 5 if x > 3 then return 1 else return 2 end")
        self.assertEqual(run_program(p), 1)

    def test_while_loop(self):
        p = compile_source("local x = 0 while x < 4 do x = x + 1 end return x")
        self.assertEqual(run_program(p), 4)

    def test_logical_and_unary(self):
        p = compile_source("local x = not false if x and true then return 9 end return 0")
        self.assertEqual(run_program(p), 9)

    def test_round_trip(self):
        p = compile_source('local label = "hello" return label')
        self.assertEqual(run_program(decode_program(encode_program(p))), "hello")

    def test_transform_preserves_result(self):
        p = compile_source("local a = 20 local b = 22 return a + b")
        q = transform_bytecode(p, seed=5)
        # Transformed opcode names must remain serializable for the Luau runtime.
        decode_program(encode_program(q))
        # Reference VM accepts canonical op names; transformed package is intended for Luau runtime.
        restored = dict(q)
        restored["code"] = [[q["opmap"].get(i[0], i[0]), *i[1:]] for i in q["code"]]
        restored.pop("opmap", None)
        self.assertEqual(run_program(restored), 42)

    def test_rejects_unsupported_call(self):
        with self.assertRaises(CompileError):
            compile_source('print("hi")')

    def test_step_limit(self):
        p = compile_source("while true do local x = 1 end")
        with self.assertRaises(BytecodeError):
            run_program(p, max_steps=20)

if __name__ == "__main__":
    unittest.main()
